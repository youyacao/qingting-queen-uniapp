export const BASE_URL = 'https://qingtingapi.youyacao.com/api/v1/'
// export const BASE_URL = 'https://oldqingtingapi.youyacao.com/api/v1/'